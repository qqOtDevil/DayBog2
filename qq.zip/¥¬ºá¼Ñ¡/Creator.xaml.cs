﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Экзамен
{
    /// <summary>
    /// Логика взаимодействия для Creator.xaml
    /// </summary>
    public partial class Creator : Page
    {
        public Creator()
        {
            InitializeComponent();
            var name = "Дада нетнет";// Имя и отчество организатора
            Fio.Text = name;

            var timeH = DateTime.Now.Hour;
            if (timeH >= 9 & timeH <= 11) {
                Good.Text = "Доброе утро!";
                return;
            } else if (timeH >= 11 & timeH <= 18) {
                Good.Text = "Доброе день!";
                return;
            } else if (timeH >= 18 & timeH <= 0){
                Good.Text = "Доброе вечер!";
                return;
            }
        }
    }
}
